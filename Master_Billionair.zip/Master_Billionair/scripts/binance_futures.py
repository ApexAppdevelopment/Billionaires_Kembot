
import requests
import os

# Use environment variables for API keys for security reasons
API_KEY = os.environ.get("BINANCE_API_KEY")
API_SECRET = os.environ.get("BINANCE_API_SECRET")

# Base URL for Binance Futures API
BASE_URL = "https://fapi.binance.com/fapi/v1"

# Set headers with API key
headers = {
    "X-MBX-APIKEY": API_KEY
}

def set_leverage(symbol, leverage):
    """Set leverage for a given symbol."""
    data = {
        "symbol": symbol,
        "leverage": leverage
    }
    response = requests.post(f"{BASE_URL}/leverage", headers=headers, data=data)
    response.raise_for_status()
    return response.json()

def get_balance():
    """Get the balance of USDT."""
    response = requests.get(f"{BASE_URL}/balance", headers=headers)
    response.raise_for_status()
    balances = response.json()
    for asset_balance in balances:
        if asset_balance['asset'] == 'USDT':
            return float(asset_balance['balance'])
    return 0

def place_futures_order(symbol, side, quantity):
    """Place a futures order with the given parameters."""
    data = {
        "symbol": symbol,
        "side": side,
        "type": "MARKET",
        "quantity": quantity
    }
    response = requests.post(f"{BASE_URL}/order", headers=headers, data=data)
    response.raise_for_status()
    return response.json()
